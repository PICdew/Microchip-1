16F690 Ex1 Assembly language Example
====================================

This is an example of an assembly language study example from a home learning course on offer in the UK.

Microchip forum topic: http://www.microchip.com/forums/FindPost/1038988